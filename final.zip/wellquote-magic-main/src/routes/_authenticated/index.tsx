import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Plus, Trash2, FileDown, Printer, FilePlus2, Phone, MapPin, LogOut,
  FileText, Receipt, MessageCircle, Wallet, TrendingUp, AlertCircle, BellRing, Save,
  Sun, Moon, User, Monitor, ShieldOff,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { generateQuotationPDF, type Quotation, type QuotationItem, type DocType } from "@/lib/quotation-pdf";
import { listDocuments, saveDocument, deleteDocument, updatePaidAmount } from "@/lib/documents.functions";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/logo.png";
import heroImg from "@/assets/borewell-hero.jpg";

export const Route = createFileRoute("/_authenticated/")({ component: Index });

const COMPANY = {
  companyName: "RAUT BOREWELLS & PUMPS",
  companyTagline: "Drilling • Submersible Pumps • Installation",
  companyAddress: "Shop No. 16, 17, Devi Heaven, Kathora Road, Amravati - 444 604",
  contacts: "Ajay Raut: 9765857478 • Vijay Raut: 9890515430 • Kapil Raut: 9307498437 • Tanay Raut: 8010796319",
};

const DEFAULT_ITEMS: QuotationItem[] = [
  { description: "Surface Bore", size: "", qty: "", rate: "", amount: "" },
  { description: "Casing PVC Pipe", size: "", qty: "", rate: "", amount: "" },
  { description: "Covering Pipe", size: "", qty: "", rate: "", amount: "" },
  { description: "Submersible Pump", size: "", qty: "", rate: "", amount: "" },
  { description: "Starter or Panel Board", size: "", qty: "", rate: "", amount: "" },
  { description: "HDPE Pipe", size: "", qty: "", rate: "", amount: "" },
  { description: "Cable 3 core/sq.mm", size: "", qty: "", rate: "", amount: "" },
  { description: "Bore cap & Clamp", size: "", qty: "", rate: "", amount: "" },
  { description: "SS nipple kit, SS bolt & nut, Bush & GI Accessories", size: "", qty: "", rate: "", amount: "" },
  { description: "Heavy / Light brass NRV valve", size: "", qty: "", rate: "", amount: "" },
  { description: "Installation Charges and Carting", size: "", qty: "", rate: "", amount: "" },
];

const today = () => new Date().toISOString().slice(0, 10);

type SavedDoc = {
  id: string;
  doc_type: DocType;
  doc_no: string;
  doc_date: string;
  booking_date: string | null;
  customer_name: string;
  customer_mobile: string;
  customer_address: string;
  advance_amount: string;
  paid_amount: number;
  gst_rate: number;
  gst_amount: number;
  grand_total: number;
  items: QuotationItem[];
  terms: string;
  total: number;
  created_at: string;
};

type FormState = Quotation & { docType: DocType };

const blank = (docType: DocType, no: string): FormState => ({
  ...COMPANY,
  docType,
  quotationNo: no,
  date: today(),
  bookingDate: today(),
  customerName: "",
  customerMobile: "",
  customerAddress: "",
  advanceAmount: "",
  paidAmount: 0,
  gstRate: 18,
  items: DEFAULT_ITEMS.map((i) => ({ ...i })),
  terms:
    "1. 50% advance with order, balance on completion.\n2. Quotation valid for 15 days.\n3. Water yield depends on geological conditions.\n4. GST extra as applicable.",
});

function nextNo(docs: SavedDoc[], docType: DocType): string {
  const base = docType === "bill" ? 1000 : 320;
  const max = docs
    .filter((d) => d.doc_type === docType)
    .reduce((m, s) => Math.max(m, parseInt(s.doc_no) || 0), base);
  return String(max + 1);
}

function Index() {
  const navigate = useNavigate();
  const list = useServerFn(listDocuments);
  const save = useServerFn(saveDocument);
  const del = useServerFn(deleteDocument);
  const updatePaid = useServerFn(updatePaidAmount);

  const [docs, setDocs] = useState<SavedDoc[]>([]);
  const [docType, setDocType] = useState<DocType>("quotation");
  const [q, setQ] = useState<FormState>(blank("quotation", "321"));
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"editor" | "dashboard">("editor");
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window === "undefined") return "light";
    return (localStorage.getItem("theme") as "light" | "dark") || "light";
  });
  const [userEmail, setUserEmail] = useState<string>("");
  const [loginAt, setLoginAt] = useState<string>("");
  const [deviceInfo, setDeviceInfo] = useState<string>("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUserEmail(data.user?.email || "");
      const created = data.user?.last_sign_in_at || data.user?.created_at;
      if (created) setLoginAt(new Date(created).toLocaleString());
    });
    if (typeof navigator !== "undefined") {
      const ua = navigator.userAgent;
      const isMobile = /Mobile|Android|iPhone|iPad/.test(ua);
      const browser = /Chrome/.test(ua) ? "Chrome" : /Safari/.test(ua) ? "Safari" : /Firefox/.test(ua) ? "Firefox" : "Browser";
      const os = /Android/.test(ua) ? "Android" : /iPhone|iPad|iOS/.test(ua) ? "iOS" : /Windows/.test(ua) ? "Windows" : /Mac/.test(ua) ? "macOS" : "Device";
      setDeviceInfo(`${browser} on ${os}${isMobile ? " (Mobile)" : ""}`);
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  const refresh = async () => {
    try {
      const res = await list();
      const list2 = res.documents as unknown as SavedDoc[];
      setDocs(list2);
      return list2;
    } catch (e: any) {
      toast.error(e.message || "Failed to load");
      return [] as SavedDoc[];
    }
  };

  useEffect(() => {
    refresh().then((d) => {
      setQ(blank("quotation", nextNo(d, "quotation")));
      setLoading(false);
    });
    // eslint-disable-next-line
  }, []);

  const switchType = (type: DocType) => {
    setDocType(type);
    setEditingId(null);
    setQ(blank(type, nextNo(docs, type)));
  };

  const update = <K extends keyof FormState>(k: K, v: FormState[K]) =>
    setQ((p) => ({ ...p, [k]: v }));

  const updateItem = (idx: number, field: keyof QuotationItem, value: string) => {
    setQ((p) => {
      const items = [...p.items];
      items[idx] = { ...items[idx], [field]: value };
      if (field === "qty" || field === "rate") {
        const qty = parseFloat(field === "qty" ? value : items[idx].qty) || 0;
        const rate = parseFloat(field === "rate" ? value : items[idx].rate) || 0;
        if (qty && rate) items[idx].amount = String(qty * rate);
      }
      return { ...p, items };
    });
  };

  const addRow = () =>
    update("items", [...q.items, { description: "", size: "", qty: "", rate: "", amount: "" }]);
  const removeRow = (idx: number) => update("items", q.items.filter((_, i) => i !== idx));

  const subtotal = q.items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const gstAmount = Math.round(subtotal * (q.gstRate || 0)) / 100;
  const grandTotal = subtotal + gstAmount;
  const balanceDue = grandTotal - (q.paidAmount || 0);

  /** Save and return the row id (for follow-up actions). */
  const persist = async (): Promise<string | null> => {
    if (!q.customerName.trim()) {
      toast.error("Please enter customer name first");
      return null;
    }
    try {
      const res = await save({
        data: {
          id: editingId,
          doc_type: docType,
          doc_no: q.quotationNo,
          doc_date: q.date,
          booking_date: q.bookingDate || null,
          customer_name: q.customerName,
          customer_mobile: q.customerMobile,
          customer_address: q.customerAddress,
          advance_amount: q.advanceAmount,
          paid_amount: q.paidAmount || 0,
          gst_rate: q.gstRate || 0,
          gst_amount: gstAmount,
          grand_total: grandTotal,
          items: q.items,
          terms: q.terms,
          total: subtotal,
        },
      });
      const id = (res.document as any).id as string;
      setEditingId(id);
      await refresh();
      return id;
    } catch (e: any) {
      toast.error(e.message || "Save failed");
      return null;
    }
  };

  const newDoc = () => {
    setEditingId(null);
    setQ(blank(docType, nextNo(docs, docType)));
    toast.info(`New ${docType}`);
  };

  const loadDoc = (d: SavedDoc) => {
    setDocType(d.doc_type);
    setEditingId(d.id);
    setTab("editor");
    setQ({
      ...COMPANY,
      docType: d.doc_type,
      quotationNo: d.doc_no,
      date: d.doc_date,
      bookingDate: d.booking_date || "",
      customerName: d.customer_name,
      customerMobile: d.customer_mobile,
      customerAddress: d.customer_address || "",
      advanceAmount: d.advance_amount,
      paidAmount: Number(d.paid_amount) || 0,
      gstRate: Number(d.gst_rate) || 0,
      items: Array.isArray(d.items) && d.items.length ? d.items : DEFAULT_ITEMS.map((i) => ({ ...i })),
      terms: d.terms,
    });
  };

  const deleteDoc = async (id: string) => {
    if (!confirm("Delete this document?")) return;
    try {
      await del({ data: { id } });
      await refresh();
      if (editingId === id) newDoc();
      toast.success("Deleted");
    } catch (e: any) {
      toast.error(e.message || "Delete failed");
    }
  };

  // === Print / PDF / WhatsApp: all auto-save first ===
  const handleSave = async () => {
    const id = await persist();
    if (!id) return;
    toast.success("Saved");
  };

  const handlePDF = async () => {
    const id = await persist();
    if (!id) return;
    await generateQuotationPDF(q, "save", logo);
    toast.success("PDF downloaded");
  };

  const handlePrint = async () => {
    const id = await persist();
    if (!id) return;
    await generateQuotationPDF(q, "print", logo);
    toast.success("Opening print dialog");
  };

  /** Share via WhatsApp: tries to attach the PDF directly (mobile),
   *  falls back to downloading the PDF + opening wa.me with text. */
  const shareToWhatsApp = async (
    quotation: Quotation,
    mobileRaw: string,
    message: string,
    fileLabel: string,
  ) => {
    const mobile = (mobileRaw || "").replace(/\D/g, "");
    if (!mobile) {
      toast.error("Customer mobile required for WhatsApp");
      return;
    }
    const wa = mobile.length === 10 ? `91${mobile}` : mobile;

    // Build the PDF as a blob
    const blob = (await generateQuotationPDF(quotation, "blob", logo)) as Blob;
    const file = new File(
      [blob],
      `${fileLabel}-${quotation.quotationNo || "doc"}.pdf`,
      { type: "application/pdf" },
    );

    // Try native share with file attachment (mobile WhatsApp supports this)
    const nav = navigator as any;
    if (nav.canShare && nav.canShare({ files: [file] })) {
      try {
        await nav.share({ files: [file], title: fileLabel, text: message });
        toast.success("Shared with PDF attached");
        return;
      } catch (e: any) {
        if (e?.name === "AbortError") return; // user cancelled
        // fall through to fallback
      }
    }

    // Fallback: download the PDF, then open WhatsApp chat with text
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name;
    a.click();
    URL.revokeObjectURL(url);
    window.open(
      `https://wa.me/${wa}?text=${encodeURIComponent(
        message + "\n\n(PDF downloaded — please attach it here.)",
      )}`,
      "_blank",
    );
    toast.success("PDF downloaded & WhatsApp opened");
  };

  const handleWhatsApp = async () => {
    const id = await persist();
    if (!id) return;
    const label = docType === "bill" ? "Bill" : "Quotation";
    const msg =
      `Hello ${q.customerName},\n\n` +
      `Your ${label} from ${COMPANY.companyName}\n` +
      `No: ${q.quotationNo} | Date: ${q.date}\n` +
      `Grand Total: Rs. ${grandTotal.toLocaleString("en-IN")}` +
      (docType === "bill"
        ? `\nPaid: Rs. ${(q.paidAmount || 0).toLocaleString("en-IN")}` +
          `\nBalance Due: Rs. ${balanceDue.toLocaleString("en-IN")}`
        : "") +
      `\n\nThank you!`;
    await shareToWhatsApp(q, q.customerMobile, msg, label);
  };

  /** Convert a saved bill into a Quotation form payload for re-sharing. */
  const savedToQuotation = (d: SavedDoc): Quotation => ({
    ...COMPANY,
    docType: d.doc_type,
    quotationNo: d.doc_no,
    date: d.doc_date,
    bookingDate: d.booking_date || "",
    customerName: d.customer_name,
    customerMobile: d.customer_mobile,
    customerAddress: d.customer_address || "",
    advanceAmount: d.advance_amount,
    paidAmount: Number(d.paid_amount) || 0,
    gstRate: Number(d.gst_rate) || 0,
    items: Array.isArray(d.items) && d.items.length ? d.items : [],
    terms: d.terms,
  });

  /** Send a payment-due reminder on WhatsApp with the bill PDF attached. */
  const sendDueReminder = async (d: SavedDoc) => {
    const due = Number(d.grand_total) - Number(d.paid_amount || 0);
    if (due <= 0) {
      toast.info("This bill is fully paid");
      return;
    }
    const msg =
      `Hello ${d.customer_name}, this is a friendly reminder from ${COMPANY.companyName}.\n\n` +
      `Bill No: ${d.doc_no} (Date: ${d.doc_date})\n` +
      `Grand Total: Rs. ${Number(d.grand_total).toLocaleString("en-IN")}\n` +
      `Paid: Rs. ${Number(d.paid_amount || 0).toLocaleString("en-IN")}\n` +
      `Balance Due: Rs. ${due.toLocaleString("en-IN")}\n\n` +
      `Kindly arrange the pending payment at your earliest. The bill is attached for your reference.\n\nThank you!`;
    await shareToWhatsApp(savedToQuotation(d), d.customer_mobile, msg, "Bill");
  };


  const markPayment = async (d: SavedDoc) => {
    const due = Number(d.grand_total) - Number(d.paid_amount || 0);
    const input = prompt(
      `Customer: ${d.customer_name}\nGrand Total: ₹${Number(d.grand_total).toLocaleString("en-IN")}\nPaid so far: ₹${Number(d.paid_amount || 0).toLocaleString("en-IN")}\nDue: ₹${due.toLocaleString("en-IN")}\n\nEnter NEW total paid amount:`,
      String(d.paid_amount || 0),
    );
    if (input === null) return;
    const paid = parseFloat(input);
    if (isNaN(paid) || paid < 0) {
      toast.error("Invalid amount");
      return;
    }
    try {
      await updatePaid({ data: { id: d.id, paid_amount: paid } });
      await refresh();
      toast.success("Payment updated");
    } catch (e: any) {
      toast.error(e.message || "Update failed");
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out from this device");
    navigate({ to: "/login" });
  };

  const logoutAll = async () => {
    if (!confirm("Sign out from ALL devices? You'll need to log in again everywhere.")) return;
    try {
      await supabase.auth.signOut({ scope: "global" });
      toast.success("Signed out from all devices");
      navigate({ to: "/login" });
    } catch (e: any) {
      toast.error(e.message || "Failed to sign out everywhere");
    }
  };

  // === Dashboard aggregates (bills only) ===
  const bills = useMemo(() => docs.filter((d) => d.doc_type === "bill"), [docs]);
  const totals = useMemo(() => {
    const billed = bills.reduce((s, d) => s + Number(d.grand_total || 0), 0);
    const collected = bills.reduce((s, d) => s + Number(d.paid_amount || 0), 0);
    return { billed, collected, due: billed - collected };
  }, [bills]);

  const byCustomer = useMemo(() => {
    const map = new Map<string, { name: string; mobile: string; billed: number; paid: number; due: number; count: number }>();
    for (const b of bills) {
      const key = (b.customer_mobile || b.customer_name).trim();
      const cur = map.get(key) || { name: b.customer_name, mobile: b.customer_mobile, billed: 0, paid: 0, due: 0, count: 0 };
      cur.billed += Number(b.grand_total || 0);
      cur.paid += Number(b.paid_amount || 0);
      cur.due = cur.billed - cur.paid;
      cur.count += 1;
      map.set(key, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.due - a.due);
  }, [bills]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  }

  const filtered = docs.filter((d) => d.doc_type === docType);
  const typeLabel = docType === "bill" ? "Bill" : "Quotation";

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <header className="relative overflow-hidden text-white">
        <div className="absolute inset-0">
          <img src={heroImg} alt="Borewell drilling rig" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.25_0.15_250)/0.95] via-[oklch(0.35_0.18_245)/0.85] to-[oklch(0.45_0.18_230)/0.7]" />
        </div>
        <div className="relative mx-auto max-w-6xl px-6 py-6 flex items-center gap-5">
          <img src={logo} alt="Raut Borewells logo" width={72} height={72} className="size-16 rounded-full bg-white p-1 shadow-lg" />
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">{COMPANY.companyName}</h1>
            <p className="text-sm md:text-base opacity-95">{COMPANY.companyTagline}</p>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs opacity-90">
              <span className="inline-flex items-center gap-1"><MapPin className="size-3" />{COMPANY.companyAddress}</span>
              <span className="inline-flex items-center gap-1"><Phone className="size-3" />{COMPANY.contacts}</span>
            </div>
          </div>
          <Button variant="secondary" size="sm" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title="Toggle theme">
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="sm" title="Account">
                <User className="size-4" />
                <span className="hidden sm:inline">Account</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72">
              <DropdownMenuLabel>
                <div className="space-y-0.5">
                  <div className="text-xs text-muted-foreground">Signed in as</div>
                  <div className="text-sm font-semibold truncate">{userEmail || "—"}</div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="px-2 py-1.5 text-xs text-muted-foreground space-y-1">
                <div className="flex items-center gap-2">
                  <Monitor className="size-3.5" />
                  <span className="truncate">{deviceInfo || "This device"}</span>
                </div>
                {loginAt && (
                  <div className="pl-5">Last sign-in: {loginAt}</div>
                )}
                <div className="pl-5 text-[10px] italic">Current session</div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout}>
                <LogOut className="size-4" /> Log out this device
              </DropdownMenuItem>
              <DropdownMenuItem onClick={logoutAll} className="text-destructive focus:text-destructive">
                <ShieldOff className="size-4" /> Log out everywhere
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        {/* Top-level tabs */}
        <div className="relative mx-auto max-w-6xl px-6 flex gap-1">
          <TopTab active={tab === "editor"} onClick={() => setTab("editor")}>Quotations & Bills</TopTab>
          <TopTab active={tab === "dashboard"} onClick={() => setTab("dashboard")}>Dashboard</TopTab>
        </div>
      </header>

      {tab === "dashboard" ? (
        <Dashboard totals={totals} byCustomer={byCustomer} bills={bills} onMarkPayment={markPayment} onOpen={loadDoc} onRemind={sendDueReminder} />
      ) : (
        <main className="mx-auto max-w-6xl px-6 py-8 grid lg:grid-cols-[1fr_280px] gap-6">
          <div className="space-y-6 min-w-0">
            {/* Doc type tabs */}
            <div className="flex gap-2 border-b">
              <button
                onClick={() => switchType("quotation")}
                className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px inline-flex items-center gap-2 ${docType === "quotation" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
              >
                <FileText className="size-4" /> Quotation
              </button>
              <button
                onClick={() => switchType("bill")}
                className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px inline-flex items-center gap-2 ${docType === "bill" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
              >
                <Receipt className="size-4" /> Bill / Invoice
              </button>
            </div>

            {/* Action bar */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-primary">
                {editingId ? `Editing ${typeLabel} #${q.quotationNo}` : `New ${typeLabel} #${q.quotationNo}`}
              </h2>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={newDoc}><FilePlus2 className="size-4" /> New</Button>
                <Button variant="outline" onClick={handleSave}><Save className="size-4" /> Save</Button>
                <Button variant="outline" onClick={handlePDF}><FileDown className="size-4" /> PDF</Button>
                <Button variant="outline" onClick={handlePrint}><Printer className="size-4" /> Print</Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={handleWhatsApp}>
                  <MessageCircle className="size-4" /> WhatsApp
                </Button>
              </div>
            </div>

            <Card className="p-6 space-y-4">
              <h2 className="font-semibold text-lg">{typeLabel} Info</h2>
              <div className="grid md:grid-cols-3 gap-4">
                <Field label={`${typeLabel} No.`} value={q.quotationNo} onChange={(v) => update("quotationNo", v)} />
                <Field label="Date" type="date" value={q.date} onChange={(v) => update("date", v)} />
                <Field label="Booking Date" type="date" value={q.bookingDate} onChange={(v) => update("bookingDate", v)} />
                <Field label="Customer Name" value={q.customerName} onChange={(v) => update("customerName", v)} />
                <Field label="Mobile No." value={q.customerMobile} onChange={(v) => update("customerMobile", v)} />
                <Field label="Advance Amount" value={q.advanceAmount} onChange={(v) => update("advanceAmount", v)} />
                <div className="md:col-span-3 space-y-1.5">
                  <Label className="text-xs">Customer Address</Label>
                  <Textarea rows={2} value={q.customerAddress} onChange={(e) => update("customerAddress", e.target.value)} />
                </div>
              </div>
            </Card>

            <Card className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold text-lg">Items</h2>
                <Button size="sm" onClick={addRow}><Plus className="size-4" /> Add Row</Button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-secondary text-secondary-foreground text-left">
                      <th className="p-2 w-10">#</th>
                      <th className="p-2">Description</th>
                      <th className="p-2 w-24">Size</th>
                      <th className="p-2 w-20">Qty</th>
                      <th className="p-2 w-24">Rate</th>
                      <th className="p-2 w-28">Amount</th>
                      <th className="p-2 w-10"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {q.items.map((it, i) => (
                      <tr key={i} className="border-t">
                        <td className="p-2 text-muted-foreground">{i + 1}</td>
                        <td className="p-1"><Input value={it.description} onChange={(e) => updateItem(i, "description", e.target.value)} /></td>
                        <td className="p-1"><Input value={it.size} onChange={(e) => updateItem(i, "size", e.target.value)} /></td>
                        <td className="p-1"><Input value={it.qty} onChange={(e) => updateItem(i, "qty", e.target.value)} /></td>
                        <td className="p-1"><Input value={it.rate} onChange={(e) => updateItem(i, "rate", e.target.value)} /></td>
                        <td className="p-1"><Input value={it.amount} onChange={(e) => updateItem(i, "amount", e.target.value)} /></td>
                        <td className="p-1">
                          <Button variant="ghost" size="icon" onClick={() => removeRow(i)}>
                            <Trash2 className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals + GST */}
              <div className="ml-auto max-w-sm space-y-2 text-sm">
                <Row k="Subtotal" v={`₹ ${subtotal.toLocaleString("en-IN")}`} />
                <div className="flex items-center gap-3">
                  <Label className="text-xs whitespace-nowrap">GST Rate (%)</Label>
                  <Input
                    type="number"
                    className="h-8"
                    value={q.gstRate}
                    onChange={(e) => update("gstRate", parseFloat(e.target.value) || 0)}
                  />
                  <span className="whitespace-nowrap">₹ {gstAmount.toLocaleString("en-IN")}</span>
                </div>
                <div className="border-t pt-2">
                  <Row k="Grand Total" v={`₹ ${grandTotal.toLocaleString("en-IN")}`} bold />
                </div>
                {docType === "bill" && (
                  <>
                    <div className="flex items-center gap-3">
                      <Label className="text-xs whitespace-nowrap">Paid Amount</Label>
                      <Input
                        type="number"
                        className="h-8"
                        value={q.paidAmount}
                        onChange={(e) => update("paidAmount", parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <Row
                      k="Balance Due"
                      v={`₹ ${balanceDue.toLocaleString("en-IN")}`}
                      bold
                      className={balanceDue > 0 ? "text-destructive" : "text-green-600"}
                    />
                  </>
                )}
              </div>
            </Card>

            <Card className="p-6 space-y-3">
              <h2 className="font-semibold text-lg">Terms & Conditions</h2>
              <Textarea rows={5} value={q.terms} onChange={(e) => update("terms", e.target.value)} />
            </Card>
          </div>

          <aside className="space-y-3">
            <Card className="p-4">
              <h3 className="font-semibold text-primary mb-3">Saved {typeLabel}s ({filtered.length})</h3>
              {filtered.length === 0 ? (
                <p className="text-sm text-muted-foreground">None yet. Use Save, PDF, Print or WhatsApp to create one.</p>
              ) : (
                <ul className="space-y-2 max-h-[60vh] overflow-y-auto">
                  {filtered.map((s) => {
                    const due = Number(s.grand_total) - Number(s.paid_amount || 0);
                    return (
                      <li
                        key={s.id}
                        className={`rounded-md border p-2.5 text-sm transition-colors ${editingId === s.id ? "border-primary bg-accent/40" : "hover:bg-muted"}`}
                      >
                        <button className="w-full text-left" onClick={() => loadDoc(s)}>
                          <div className="font-medium">#{s.doc_no} — {s.customer_name || "Untitled"}</div>
                          <div className="text-xs text-muted-foreground">{s.doc_date} • ₹{Number(s.grand_total).toLocaleString("en-IN")}</div>
                          {s.doc_type === "bill" && (
                            <div className={`text-xs font-medium ${due > 0 ? "text-destructive" : "text-green-600"}`}>
                              {due > 0 ? `Due ₹${due.toLocaleString("en-IN")}` : "Paid"}
                            </div>
                          )}
                        </button>
                        <div className="mt-1.5 flex justify-end gap-1">
                          {s.doc_type === "bill" && due > 0 && (
                            <Button variant="ghost" size="sm" className="text-amber-600 hover:text-amber-700" onClick={() => sendDueReminder(s)}>
                              <BellRing className="size-3" /> Remind
                            </Button>
                          )}
                          <Button variant="ghost" size="sm" onClick={() => deleteDoc(s.id)}>
                            <Trash2 className="size-3" /> Delete
                          </Button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </Card>
          </aside>
        </main>
      )}
    </div>
  );
}

function TopTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-medium rounded-t-md ${active ? "bg-background text-foreground" : "bg-white/10 text-white/80 hover:bg-white/20"}`}
    >
      {children}
    </button>
  );
}

function Row({ k, v, bold, className = "" }: { k: string; v: string; bold?: boolean; className?: string }) {
  return (
    <div className={`flex justify-between ${bold ? "font-bold text-base" : ""} ${className}`}>
      <span>{k}</span><span>{v}</span>
    </div>
  );
}

function Field({
  label, value, onChange, type = "text",
}: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      <Input type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function Dashboard({
  totals, byCustomer, bills, onMarkPayment, onOpen, onRemind,
}: {
  totals: { billed: number; collected: number; due: number };
  byCustomer: { name: string; mobile: string; billed: number; paid: number; due: number; count: number }[];
  bills: SavedDoc[];
  onMarkPayment: (d: SavedDoc) => void;
  onOpen: (d: SavedDoc) => void;
  onRemind: (d: SavedDoc) => void;
}) {
  const [filter, setFilter] = useState<"all" | "due" | "paid">("all");
  const filteredCustomers = byCustomer.filter((c) =>
    filter === "all" ? true : filter === "due" ? c.due > 0 : c.due <= 0,
  );
  return (
    <main className="mx-auto max-w-6xl px-6 py-8 space-y-6">
      <div className="grid sm:grid-cols-3 gap-4">
        <StatCard icon={<TrendingUp className="size-5" />} label="Total Billed" value={totals.billed} color="text-primary" />
        <StatCard icon={<Wallet className="size-5" />} label="Total Collected" value={totals.collected} color="text-green-600" />
        <StatCard icon={<AlertCircle className="size-5" />} label="Total Due" value={totals.due} color="text-destructive" />
      </div>

      <Card className="p-6 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h2 className="text-lg font-semibold">Customer Ledger</h2>
          <div className="flex gap-2">
            {(["all", "due", "paid"] as const).map((f) => (
              <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
                {f === "all" ? "All" : f === "due" ? "With Dues" : "Fully Paid"}
              </Button>
            ))}
          </div>
        </div>
        {filteredCustomers.length === 0 ? (
          <p className="text-sm text-muted-foreground">No customers yet. Create a Bill to track payments.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-secondary text-left">
                  <th className="p-2">Customer</th>
                  <th className="p-2">Mobile</th>
                  <th className="p-2 text-right">Bills</th>
                  <th className="p-2 text-right">Billed</th>
                  <th className="p-2 text-right">Paid</th>
                  <th className="p-2 text-right">Due</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((c) => (
                  <tr key={c.name + c.mobile} className="border-t">
                    <td className="p-2 font-medium">{c.name}</td>
                    <td className="p-2 text-muted-foreground">{c.mobile || "-"}</td>
                    <td className="p-2 text-right">{c.count}</td>
                    <td className="p-2 text-right">₹{c.billed.toLocaleString("en-IN")}</td>
                    <td className="p-2 text-right text-green-600">₹{c.paid.toLocaleString("en-IN")}</td>
                    <td className={`p-2 text-right font-semibold ${c.due > 0 ? "text-destructive" : "text-green-600"}`}>
                      ₹{c.due.toLocaleString("en-IN")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="p-6 space-y-4">
        <h2 className="text-lg font-semibold">All Bills</h2>
        {bills.length === 0 ? (
          <p className="text-sm text-muted-foreground">No bills yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-secondary text-left">
                  <th className="p-2">Bill No.</th>
                  <th className="p-2">Date</th>
                  <th className="p-2">Customer</th>
                  <th className="p-2 text-right">Grand Total</th>
                  <th className="p-2 text-right">Paid</th>
                  <th className="p-2 text-right">Due</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {bills.map((b) => {
                  const due = Number(b.grand_total) - Number(b.paid_amount || 0);
                  return (
                    <tr key={b.id} className="border-t">
                      <td className="p-2 font-medium">
                        <button className="text-primary hover:underline" onClick={() => onOpen(b)}>#{b.doc_no}</button>
                      </td>
                      <td className="p-2">{b.doc_date}</td>
                      <td className="p-2">{b.customer_name}</td>
                      <td className="p-2 text-right">₹{Number(b.grand_total).toLocaleString("en-IN")}</td>
                      <td className="p-2 text-right text-green-600">₹{Number(b.paid_amount || 0).toLocaleString("en-IN")}</td>
                      <td className={`p-2 text-right font-semibold ${due > 0 ? "text-destructive" : "text-green-600"}`}>
                        ₹{due.toLocaleString("en-IN")}
                      </td>
                      <td className="p-2 text-right">
                        <div className="inline-flex gap-1">
                          {due > 0 && (
                            <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-white" onClick={() => onRemind(b)}>
                              <BellRing className="size-3" /> Remind
                            </Button>
                          )}
                          <Button size="sm" variant="outline" onClick={() => onMarkPayment(b)}>
                            <Wallet className="size-3" /> Record Payment
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </main>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  return (
    <Card className="p-5">
      <div className={`flex items-center gap-2 ${color}`}>{icon}<span className="text-sm font-medium">{label}</span></div>
      <div className={`text-2xl font-bold mt-2 ${color}`}>₹{value.toLocaleString("en-IN")}</div>
    </Card>
  );
}
