import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Droplet, Lock } from "lucide-react";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/" });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/` },
        });
        if (error) throw error;
        toast.success("Admin account created. Signing you in...");
        const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
        if (signInErr) {
          toast.info("Check your email to confirm the account, then sign in.");
          setMode("signin");
          return;
        }
        navigate({ to: "/" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/" });
      }
    } catch (err: any) {
      toast.error(err.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[oklch(0.25_0.15_250)] via-[oklch(0.35_0.18_245)] to-[oklch(0.55_0.18_220)] px-4">
      <Card className="w-full max-w-md p-8 space-y-6 shadow-2xl">
        <div className="flex flex-col items-center gap-3">
          <img src={logo} alt="Raut Borewells" className="size-20 rounded-full shadow-md" />
          <div className="text-center">
            <h1 className="text-2xl font-bold text-primary">RAUT BOREWELLS & PUMPS</h1>
            <p className="text-xs text-muted-foreground inline-flex items-center gap-1 mt-1">
              <Lock className="size-3" /> Admin Access Only
            </p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Admin Email</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            <Droplet className="size-4" />
            {loading ? "Please wait..." : mode === "signup" ? "Create Admin Account" : "Sign In"}
          </Button>
        </form>

        <div className="text-center text-sm text-muted-foreground">
          {mode === "signin" ? (
            <>
              First time?{" "}
              <button className="text-primary font-medium hover:underline" onClick={() => setMode("signup")}>
                Create admin account
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button className="text-primary font-medium hover:underline" onClick={() => setMode("signin")}>
                Sign in
              </button>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}
