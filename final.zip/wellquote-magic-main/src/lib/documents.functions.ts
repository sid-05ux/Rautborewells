import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const itemSchema = z.object({
  description: z.string(),
  size: z.string(),
  qty: z.string(),
  rate: z.string(),
  amount: z.string(),
});

const docInput = z.object({
  id: z.string().uuid().optional().nullable(),
  doc_type: z.enum(["quotation", "bill"]),
  doc_no: z.string().min(1),
  doc_date: z.string(),
  booking_date: z.string().optional().nullable(),
  customer_name: z.string(),
  customer_mobile: z.string(),
  customer_address: z.string().default(""),
  advance_amount: z.string(),
  paid_amount: z.number().default(0),
  gst_rate: z.number().default(0),
  gst_amount: z.number().default(0),
  grand_total: z.number().default(0),
  items: z.array(itemSchema),
  terms: z.string(),
  total: z.number(),
});

export const listDocuments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("documents")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { documents: data ?? [] };
  });

export const saveDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => docInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const payload = {
      user_id: userId,
      doc_type: data.doc_type,
      doc_no: data.doc_no,
      doc_date: data.doc_date,
      booking_date: data.booking_date || null,
      customer_name: data.customer_name,
      customer_mobile: data.customer_mobile,
      customer_address: data.customer_address,
      advance_amount: data.advance_amount,
      paid_amount: data.paid_amount,
      gst_rate: data.gst_rate,
      gst_amount: data.gst_amount,
      grand_total: data.grand_total,
      items: data.items,
      terms: data.terms,
      total: data.total,
    };
    if (data.id) {
      const { data: row, error } = await supabase
        .from("documents")
        .update(payload)
        .eq("id", data.id)
        .select()
        .single();
      if (error) throw new Error(error.message);
      return { document: row };
    }
    const { data: row, error } = await supabase
      .from("documents")
      .insert(payload)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { document: row };
  });

export const updatePaidAmount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), paid_amount: z.number().min(0) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase
      .from("documents")
      .update({ paid_amount: data.paid_amount })
      .eq("id", data.id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { document: row };
  });

export const deleteDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase.from("documents").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
