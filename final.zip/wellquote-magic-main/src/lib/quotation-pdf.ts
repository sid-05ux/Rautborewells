import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export type QuotationItem = {
  description: string;
  size: string;
  qty: string;
  rate: string;
  amount: string;
};

export type DocType = "quotation" | "bill";

export type Quotation = {
  companyName: string;
  companyTagline: string;
  companyAddress: string;
  contacts: string;
  docType?: DocType;
  quotationNo: string;
  date: string;
  bookingDate: string;
  customerName: string;
  customerMobile: string;
  customerAddress: string;
  advanceAmount: string;
  paidAmount: number;
  gstRate: number;
  items: QuotationItem[];
  terms: string;
};

// Colors matching the reference design
const CYAN: [number, number, number] = [165, 234, 240]; // header band
const CYAN_SOFT: [number, number, number] = [225, 245, 248]; // title band
const ORANGE: [number, number, number] = [240, 140, 50]; // company name
const BLUE: [number, number, number] = [21, 75, 150]; // title text / totals
const TEXT: [number, number, number] = [30, 30, 30];

async function toDataURL(url: string): Promise<string> {
  const res = await fetch(url);
  const blob = await res.blob();
  return await new Promise((resolve) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result as string);
    r.readAsDataURL(blob);
  });
}

export type PDFOutput = "save" | "print" | "blob";

export async function generateQuotationPDF(
  q: Quotation,
  output: PDFOutput = "save",
  logoUrl?: string,
): Promise<Blob | void> {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();

  // Cyan header band
  doc.setFillColor(...CYAN);
  doc.rect(0, 0, pageW, 38, "F");

  // Logo
  if (logoUrl) {
    try {
      const data = await toDataURL(logoUrl);
      doc.addImage(data, "PNG", 8, 5, 28, 28);
    } catch {}
  }

  // Company name in orange
  doc.setTextColor(...ORANGE);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(q.companyName, pageW / 2, 13, { align: "center" });

  // Underline under company name
  doc.setDrawColor(...ORANGE);
  doc.setLineWidth(0.6);
  const nameW = doc.getTextWidth(q.companyName);
  doc.line(pageW / 2 - nameW / 2, 15, pageW / 2 + nameW / 2, 15);
  doc.setLineWidth(0.2);

  // Tagline / address / contacts
  doc.setTextColor(...TEXT);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  if (q.companyTagline) doc.text(q.companyTagline.toUpperCase(), pageW / 2, 21, { align: "center" });
  doc.setFontSize(8.5);
  doc.text(q.companyAddress, pageW / 2, 26, { align: "center" });
  doc.setFontSize(7.8);
  doc.text(q.contacts, pageW / 2, 31, { align: "center" });

  // Title band
  doc.setFillColor(...CYAN_SOFT);
  doc.rect(0, 42, pageW, 10, "F");
  doc.setTextColor(...BLUE);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  const title = q.docType === "bill" ? "BILL / INVOICE" : "QUOTATION";
  doc.text(title, pageW / 2, 49, { align: "center" });

  // Meta block
  doc.setTextColor(...TEXT);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  let y = 60;
  doc.text(`To: ${q.customerName}`, 14, y);
  doc.text(`No.: ${q.quotationNo}`, pageW - 14, y, { align: "right" });
  y += 6;
  doc.text(`Mobile: ${q.customerMobile}`, 14, y);
  doc.text(`Date: ${q.date}`, pageW - 14, y, { align: "right" });
  if (q.customerAddress) {
    y += 6;
    const addrLines = doc.splitTextToSize(`Address: ${q.customerAddress}`, pageW - 80);
    doc.text(addrLines, 14, y);
    y += (addrLines.length - 1) * 5;
  }
  y += 6;
  doc.text(`Booking Date: ${q.bookingDate}`, 14, y);
  doc.text(`Advance: ${q.advanceAmount || "-"}`, pageW - 14, y, { align: "right" });

  const rows = q.items
    .filter((i) => i.description || i.qty || i.rate || i.amount)
    .map((i, idx) => [String(idx + 1), i.description, i.size, i.qty, i.rate, i.amount]);

  autoTable(doc, {
    startY: y + 6,
    head: [["Sr.", "Description", "Size", "Qty", "Rate", "Amount"]],
    body: rows,
    theme: "grid",
    headStyles: { fillColor: CYAN, textColor: BLUE, fontStyle: "bold" },
    styles: { fontSize: 10, cellPadding: 2, textColor: TEXT },
    columnStyles: {
      0: { cellWidth: 12, halign: "center" },
      2: { cellWidth: 22, halign: "center" },
      3: { cellWidth: 20, halign: "center" },
      4: { cellWidth: 25, halign: "right" },
      5: { cellWidth: 30, halign: "right" },
    },
  });

  const subtotal = q.items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const gstAmt = Math.round(subtotal * (q.gstRate || 0)) / 100;
  const grandTotal = subtotal + gstAmt;

  // @ts-ignore
  let endY = doc.lastAutoTable.finalY + 6;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...TEXT);
  doc.text(`Subtotal:`, pageW - 60, endY);
  doc.text(`Rs. ${subtotal.toLocaleString("en-IN")}`, pageW - 14, endY, { align: "right" });
  endY += 5;
  doc.text(`GST (${q.gstRate || 0}%):`, pageW - 60, endY);
  doc.text(`Rs. ${gstAmt.toLocaleString("en-IN")}`, pageW - 14, endY, { align: "right" });
  endY += 6;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...BLUE);
  doc.text(`Grand Total:`, pageW - 60, endY);
  doc.text(`Rs. ${grandTotal.toLocaleString("en-IN")}`, pageW - 14, endY, { align: "right" });

  if (q.docType === "bill") {
    endY += 5;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...TEXT);
    doc.text(`Paid:`, pageW - 60, endY);
    doc.text(`Rs. ${(q.paidAmount || 0).toLocaleString("en-IN")}`, pageW - 14, endY, { align: "right" });
    endY += 5;
    const due = grandTotal - (q.paidAmount || 0);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(due > 0 ? 180 : 30, due > 0 ? 30 : 120, 30);
    doc.text(`Balance Due:`, pageW - 60, endY);
    doc.text(`Rs. ${due.toLocaleString("en-IN")}`, pageW - 14, endY, { align: "right" });
  }

  endY += 10;
  doc.setTextColor(...TEXT);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("Terms & Conditions:", 14, endY);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const termsLines = doc.splitTextToSize(q.terms || "", pageW - 28);
  doc.text(termsLines, 14, endY + 5);

  // Signatures — line above label
  const sigLabelY = doc.internal.pageSize.getHeight() - 18;
  const sigLineY = sigLabelY - 8;
  doc.setDrawColor(80, 80, 80);
  doc.line(14, sigLineY, 70, sigLineY);
  doc.line(pageW - 70, sigLineY, pageW - 14, sigLineY);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...TEXT);
  doc.text("Customer Signature", 14, sigLabelY);
  doc.text(`For ${q.companyName}`, pageW - 14, sigLabelY, { align: "right" });

  const fileLabel = q.docType === "bill" ? "Bill" : "Quotation";
  if (output === "print") {
    doc.autoPrint();
    window.open(doc.output("bloburl"), "_blank");
    return;
  }
  if (output === "blob") {
    return doc.output("blob");
  }
  doc.save(`${fileLabel}-${q.quotationNo || "new"}.pdf`);
}
